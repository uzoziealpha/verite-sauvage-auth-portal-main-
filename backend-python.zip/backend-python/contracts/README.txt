Copy FakeProdDetector.json here after deploy.
